import React from 'react'

function App() {
  const task = [
      {
        title: 'Chemistry Class',
        description: 'Attending the Chemistry Class at gk.205',
        date: '32 February 2025',
        time: '1 PM',
        status: 'Active',
      },
      {
        title: 'Calculus Class',
        description: 'Attending the Calculus Class at gk.205',
        date: '31 February 2025',
        time: '4 PM',
        status: 'Active',
      },
      {
        title: 'Computational thinking Class',
        description: 'Attending the Computational thinking Class at gk.205',
        date: '30 February 2025',
        time: '10 AM',
        status: 'Active',
      }
  ]



  return (
    <div className='justify-center w-full min-h-screen bg-blue-200 text-white'>
      <header className='absolute top-0 text-xl p-5 bg-slate-400 w-full text-center rounded-lg'>
        To-Do List App
      </header>

      <main className='pt-36 w-3/4 mx-auto' >
        {/* User Promt */}
        <div className='flex justify-center items-center'>
          <input className='bg-slate-500 p-4 rounded-2xl w-3/4 shadow-md' placeholder='Type Your Text Here'>
          </input>
          <button className='pl-2 h-12 pt-2'>
            <img src='/logo192.png' alt="enter" className='w-full h-full'/>

          </button>

        </div>
        {/* Spacing */}
        <div className='p-6'/>

        {/* To-Do List */}
        <div className='flex justify-center'> 
          <div className='w-[85%] flex flex-col gap-y-4'>
            <p className=' font-semibold text-xl'> 
              <input type='checkbox'/> Your To-Do List</p>
            <hr/>
            {task.map((currentTask, index) => (
              <div className=' bg-slate-500 p-4 rounded-2xl shadow-lg' key={index}>
              <span className='font-semibold text-xl'>
              {currentTask.title}
              </span>
              <br/>
              <br/>
              <span className='text-base'>
                {currentTask.description} <br/>
                date: {currentTask.date}<br/>
                time: {currentTask.time}<br/>
                status: {currentTask.status}<br/>
              </span>
              <input type='checkbox'/>
            </div>
            ))}
            
          </div>
        </div>

      </main>
    </div>
  )
}

export default App

