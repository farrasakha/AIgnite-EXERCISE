import './App.css';
import { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [task, setTask] = useState([
    {
     title: 'Chemistry Class',
     date: '29/11/2025',
     time: '1 PM',
     status: 'Active',
     completed: false
    },
    {
     title: 'Calculus Class',
     date: '29/11/2025',
     time: '4 PM',
     status: 'Active',
     completed: false
    },
    {
     title: 'Computational thinking Class',
     date: '29/11/2025',
     time: '10 AM',
     status: 'Active',
     completed: false
    },
  ])

const [newTask, setNewTask] = useState('');


useEffect(() =>{
  console.log(`task updated:`, task);
}, [task]);

const handleInputChange = (e) => setNewTask(e.target.value);

const extractTime = (text) => {
    const timePatterns = [/(\d{1,2}):(\d{2})\s*(AM|PM)/i, /(\d{1,2}):(\d{2})/, /(\d{1,2})\s*(AM|PM)/i];


    for (const pattern of timePatterns) {
      const match = text.match(pattern);
      if (match) {
        let hours = parseInt(match[1]);
        const minutes = match[2] ? parseInt(match[2]) : 0;
        const period = match[3];


        if (period && period.toUpperCase() === 'PM' && hours !== 12) {
          hours += 12;
        } else if (period && period.toUpperCase() === 'AM' && hours === 12) {
          hours = 0;
        }


        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      }
    }
    return null;
  };

  const getNextDay = (dayName) => {
    const today = new Date();
    const currentDay = today.getDay();

    const dayMap = {
      "minggu":0,
      "senin":1,
      "selasa":2,
      "rabu":3,
      "kamis":4,
      "jumat":5,
      "sabtu":6,
    }
  const targetDay = dayMap[dayName.toLowerCase()];
  if (targetDay === undefined) return today;

  const dayUntillTarget = (targetDay - currentDay + 7) % 7 ;
  const nextDate = new Date(today);
  nextDate.setDate(today.getDate() + (dayUntillTarget === 0 ? 7 : dayUntillTarget));
  return nextDate;
  } 

const handleAddTask = async () => {
  if (!newTask) return;
  const today = new Date();

  let extractedTask = newTask
  let extractedDate = today.toLocaleDateString('id-ID')
  let extractedTime = today.toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit'})
  console.log(process.env.REACT_APP_GEMINI_API_KEY)

    try {
      const response = await axios.post(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
        {
          contents: [
            {
              parts: [
                {
                  text: `
You are an intelligent task parser that extracts structured information from user input for a to-do list app.
Your job is to analyze natural language text and output *only* a valid JSON object following the exact schema below:


{
  "task": "string",
  "date": "ISO 8601 format (YYYY-MM-DD)",
  "time": "HH:mm (24-hour format, optional)"
}


---


Examples:
Input:
"Work on Calculus tomorrow at 3 PM"


Output:
{
  "task": "Work on calculus",
  "date": "2025-11-03",
  "time": "15:00"
}


---


Now process this input:
"${newTask}"


Current date context: ${today.toISOString().split('T')[0]} (today is ${today.toLocaleDateString('en-US', {
                    weekday: 'long',
                  })})


Output only the JSON — no explanations, no extra text.
`,
                },
              ],
            },
          ],
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': process.env.REACT_APP_GEMINI_API_KEY,
          },
        }
      );
      const aiText = response.data.candidates[0].content.parts[0].text.trim();
      console.log(response)
      const cleanJson = aiText
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();
      const parsed = JSON.parse(cleanJson);

      if (parsed.task) extractedTask = parsed.task
      if (parsed.date) extractedDate = new Date(parsed.date).toLocaleDateString('id-ID');
      if (parsed.time) extractedTime = parsed.time
    }catch (error){
      console.error ("AI API Failed");

      
      extractedTask = newTask
      extractedDate = today.toLocaleDateString('id-ID')
      extractedTime = today.toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit'})

      const taskTest = newTask.toLowerCase();
      const days = ['minggu', 'senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu']

      for (const day of days){
        if (taskTest.includes(day)){
          const nextDayDate = getNextDay(day);
          extractedDate = nextDayDate.toLocaleDateString('id-ID')
          break;
        }
      }
      const localTime = extractTime(taskTest)
      if (localTime) extractedTime = localTime
    }

    const taskToAdd = {
      title: extractedTask,
      date: extractedDate,
      time: extractedTime,
      status: 'Active',
      completed: false,
    }
    setTask([...task, taskToAdd])
    setNewTask('');
  };


const handleToggleCompleted = (index) => {
  const updatedTask = task.map((task, i) =>
    i === index ?{ ...task, completed: !task.completed } : task);
  setTask(updatedTask);
};

const handleRemoveTask = (index) => {
 const updatedTask = task.filter((_,i) => i !== index);
 setTask(updatedTask);
};

  return (
    <div className='justify-center w-full min-h-screen bg-blue-200 text-white'>
      <header className='absolute top-0 text-xl p-5 bg-slate-400 w-full text-center rounded-lg'>
        To-Do List App
      </header>

      <main className='pt-36 w-3/4 mx-auto' >
        {/* User Promt */}
        <div className='flex justify-center items-center'>
          <input className='bg-slate-500 p-4 rounded-2xl w-3/4 shadow-md' 
            placeholder='Type Your Text Here'
            value={newTask}
            onChange={handleInputChange}>
          </input>

          <button 
            className="pl-2 h-12 pt-2 scale-95"
            onClick={handleAddTask}
          >
            <img src="/enter.png" alt="enter" className="w-full h-full"/>
          </button>
        </div>
        
        {/* Spacing */}
        <div className='p-6'/>

        {/* To-Do List */}
        <div className='flex justify-center'> 
          <div className='w-[85%] flex flex-col gap-y-4'>
            <p className=' font-semibold text-xl'> 
              <input type='checkbox'/> Your To-Do List</p>
            <hr/>

            {task.map((currentTask, index) => (
              <div
                  key={index}
                  className={`bg-slate-500 p-4 rounded-2xl shadow-lg flex justify-between items-center ${
                    currentTask.completed ? 'opacity-50 line-through' : ''
                  }`}
              >
    
                <div>
                  <p className='text-base'>
                    <span className="text-xl font-semibold">{currentTask.title}</span>
                    <br/>
                    <br/>
                    date: {currentTask.date}<br/>
                    time: {currentTask.time}<br/>
                    status: {currentTask.status}<br/>
                  </p>
                  
                    <input 
                    type='checkbox'
                    checked={currentTask.completed}
                    onChange={() => handleToggleCompleted(index)}
                    />
                </div>
              
              <button
                onClick = {() => handleRemoveTask(index)}
                className='ml-4 bg-red-600 px-4 py-2 rounded-xl hover:bg-red-700'
              >
                Remove
              </button>
            </div>
            ))}
            
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;

